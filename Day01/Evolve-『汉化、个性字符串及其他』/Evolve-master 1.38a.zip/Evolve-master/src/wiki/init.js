import { } from './../achieve.js';
import { defineResources } from './../resources.js';

defineResources(true);
